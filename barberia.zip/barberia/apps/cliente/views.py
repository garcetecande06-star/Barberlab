from django.views import View
from django.views.generic import TemplateView, CreateView
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from apps.servicio.models import Servicio
from apps.valoracion.models import Valoracion

# ------------------ Index ------------------
class IndexView(TemplateView):
    template_name = 'index.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['servicios'] = Servicio.objects.all()
        context['valoraciones'] = Valoracion.objects.select_related(
            'cliente', 'barbero', 'servicio'
        ).all()
        return context

# ------------------ Login ------------------
class LoginView(View):
    template_name = 'login.html'

    def get(self, request):
        form = AuthenticationForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('opcionesTurno')  # nombre de URL a la que redirige
        return render(request, self.template_name, {'form': form})
# ------------------ Registro ------------------
class CrearUsuario(CreateView):
    template_name = 'crearUsuario.html'
    form_class = UserCreationForm
    success_url = reverse_lazy('index')  # nombre de URL

# ------------------ Opciones Turno ------------------
class opcionesTurnoView(TemplateView):
    template_name = 'opcionesTurno.html'



