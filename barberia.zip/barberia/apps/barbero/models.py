from django.db import models

class Barbero (models.Model):
    nombre= models.CharField(max_length=100)
    email= models.EmailField()
    telefono= models.CharField(max_length=20)

    def __str__(self):
        return self.Nombre