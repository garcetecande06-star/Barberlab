from django.apps import AppConfig


class BarberoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.barbero'
